package F28DA_CW1;

public class WordException extends Exception {

	public WordException(String message) {
		super("Word Index: " +  message); 
	}
}
